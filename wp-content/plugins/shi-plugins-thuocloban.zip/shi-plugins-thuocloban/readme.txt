=== shimi thuoc lo ban  ===
Contributors: 
Donate link: http://shimivn.blogspot.com
Tags: popup ,shortcode
Requires at least: 4.0
Tested up to: 4.5.3
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

thuoc lo ban dung cho phong thuy
== Description ==

i hope you can using this popup to create can show only one or show always 

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. 
2. 

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

